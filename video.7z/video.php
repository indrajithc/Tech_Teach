<?php try {
	require_once('includes/db.php');
	$a = new Database();
	
}catch (Exception $e){
	
}
 ?>


<?php 
    if(isset($_POST['key'])) {
    if(isset($_POST['user_name'])) {

        $user_name =  $_POST['user_name'];
        $user_id = $_POST['user_id'];
		$type = $_POST['type'];
		// echo  $type;
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Untitled Document</title>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">   
        
        
        <link rel="stylesheet" href="assets/css/font-awesome/css/font-awesome.min.css">
        
        
        <?php //-------------------------------------------------//?>
        
        <link rel="stylesheet" href="assets/lobibox/css/lobibox.css">  
        <link rel="stylesheet" href="assets/lobibox/css/animate.css">    
        
        
        <!----------->
        
        

        
        
        
        
        
        
        
        <style>
		
            #remoteVideos video {
               
            }
            #localVideo {
               
            }
			


.video_inoaincontent {
	transform: scaleX(-1);
    height: 100%;
    /* width: 100%; */
    object-fit: cover;
} 
.main_video {
	width: 100%;
    height: 705px;
    text-align: center;
    padding: 12px 3px;
-webkit-box-shadow: 0px 0px 37px -13px rgba(5,66,7,1);
-moz-box-shadow: 0px 0px 37px -13px rgba(5,66,7,1);
box-shadow: 0px 0px 37px -13px rgba(5,66,7,1);

}
.main_video video {
	transform: scaleX(-1);
    /* width: 100%; */
    height: 100%;
}
.mainBodyMainper {
padding: 5px;
    padding-left: 30px;	
}
.main_ne_parent {
	overflow:auto;
	width:100%;
	height:100%;	
	max-width:100%;
	max-height:100%;
	    padding: 10px;
}
.new_persons {
    width: 100%;
    min-height: 183px;
    /* padding: 10px; */
    margin-top: 6px;	
}
.new_persons:hover { 
-webkit-box-shadow: 0px 0px 28px -9px rgba(0,0,0,0.39);
-moz-box-shadow: 0px 0px 28px -9px rgba(0,0,0,0.39);
box-shadow: 0px 0px 28px -9px rgba(0,0,0,0.39);
 }
.main_ne_parent video {
	
    height: 183px;
      padding: 6px;
	 
}
.new_persn_deta {
      padding: 10px;
    width: 47%;
    /* float: right; */
    /* display: inline-block; */
    overflow: hidden;
    height: 183px;
    position: relative;
    right: 0px;
}
.volume {
    position: absolute;
    left: 15%;
    width: 70%;
    bottom: 2px;
    height: 10px;
}
            .volume_bar {
                position: absolute;
                width: 5px;
                height: 0px;
                right: 0px;
                bottom: 0px;
                background-color: #12acef;
            }

.mycntrolclass {
    position: absolute;
    width: 96%;
    /* height: 200px; */
    /* position: absolute; */
    bottom: 5px;
    padding: 20px;
    height: 155px;
}
.mycntrolclass:hover {
    background-color: rgba(0, 0, 0, 0.17);
}
.innrshwme{
	padding: 2px;
    height: 135px;
}
.innrshwme video{
    height: 120px;
}
#selectshow {
    position: absolute;
    bottom: 350px;
    left: 400px;	
}
.mainmenu80869191{
	    margin-left: 90px;
}
.mainmenu80869191 div{
	display:inline-block;
	    display: inline-block;
    font-size: 56px;
    padding: 20px 40px 20px 40px;
}
.mainmenu80869191 .zero {
	color:#0A9700;
}
.mainmenu80869191 .one {
	
	color:#FF0004;
}
.mainmenu80869191 div:hover{
	font-size:60px;
	cursor:pointer;

}
#call_clcik_9086 {
	}
        </style>
    </head>
    <body style="width:99%"> 
    <!--
    <div class="maindivone">
        <video class="video_inoaincontent" id="localVideo"></video>
        </div>
        <div id="remoteVideos"></div>

-->


<div class="row" id="myad_fot_this" user_name= <?php echo $user_name; ?>  user_id= <?php echo $user_id; ?> key="<?php echo $_POST['key']; ?>">

     <div class="col-md-8 mainBodyMainper">
    	<div class="videoContainer main_video"  > 
    <div id="localVolume" class="volume_bar"></div>
        <video id="mainViewMe" src=""  oncontextmenu="return false;"></video>
    	 
         
         <p id="selectshow" class="hidden" >select a video </p>
          <div class="mycntrolclass">
        	<div class="col-md-9">
            	<div class="mainmenu80869191">
                	<div id="call_clcik_9086_1" status=1>
                    
                    <i class="fa fa-microphone zero  hidden"></i> 
                    <i class="fa fa-microphone-slash one"></i>
                    </div >
                	<div  id="call_clcik_9086_2"  status=1>
                          <i class="fa fa-video-camera zero hidden"></i>
                          <i class="fa fa-eye-slash one"></i>
                    </div>
                	<div  id="call_clcik_9086_3" status=1> 
                    <i class="fa fa-play-circle-o zero hidden"></i>
                    	<i class="fa fa-pause-circle-o one "></i>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            	<div class="innrshwme">
        	<video id="localVideo" src="#.mp4" oncontextmenu="return false;" title="select a video"> </video>
                
                </div>
            </div>
        </div>  
        </div>  
        
       
    </div>
    <div class="col-md-4">
    	<div class="main_ne_parent"  id="remoteVideos">
    
        </div>
    </div>


</div>


		

	<script type="text/javascript" src="assets/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="assets/js/resizeable.js"></script>
    <script type="text/javascript" src="assets/js/jquery.validate.js"></script>
    <script type="text/javascript" src="assets/js/jquery.timeago.js"></script>
    
    
    <script type="text/javascript" src="assets/lobibox/js/lobibox.js"></script>
    <script type="text/javascript" src="assets/lobibox/js/messageboxes.js"></script>
    <script type="text/javascript" src="assets/lobibox/js/notifications.js"></script>
    
    
    <script type="text/javascript" src="assets/js/webRTC.js"></script>
      <?php 
	  
	
	 
	if( $type == 1) {
		
	 ?>
     <script type="text/javascript">
  /*
	$(document).ready(function(e) {
	
	//$('#nake_a_newVido_call').click(function(e) {
		
		$My_user_name = $('#myad_fot_this').attr('user_name');
		console.log('rrrrrrrrrr'+$My_user_name);
		var $key = makeid();
		$('#myad_fot_this').attr('key', $key);
		$.post('ajax.php',{action:'nake_a_newVido_call',user_name:$My_user_name, to:' all', description:'', key:$key},function(response){
									console.log('rrrrrrrrrrrr'+response);
									response =$.parseJSON(response);
									if(response){
										
									}
								});
		
  //  });
	
	function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 15; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}
	
	}); */
	
    </script>
    
    
	<?php
	}
	?>
    
    
    
        <script type="text/javascript" src="assets/js/my_webRtc.js"></script>
			
    </body>
</html>


<?php
} else {
        echo 'Unble to cnct.!';
    }
    } else {
        echo 'Unble to cnct.!';
    }
?>

<?php //include_once('footer.php'); ?>

